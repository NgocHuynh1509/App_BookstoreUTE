create definer = root@localhost trigger Trg_ReturnQuantity_Books
    after update
    on orders
    for each row
BEGIN
    IF NEW.status = 'Cancelled' AND OLD.status <> 'Cancelled' THEN
        UPDATE books b
        JOIN orderdetail od ON b.bookId = od.bookId
        SET b.quantity = b.quantity + od.quantity
        WHERE od.orderId = NEW.orderId;
    END IF;
END;

