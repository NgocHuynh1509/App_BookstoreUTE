create definer = root@localhost trigger trg_update_cart_update
    after update
    on cartdetail
    for each row
BEGIN
    UPDATE cart
    SET
        totalAmount = (
            SELECT COALESCE(SUM(quantity * unitPrice), 0)
            FROM cartdetail
            WHERE cartId = NEW.cartId
        ),
        quantity = (
            SELECT COALESCE(SUM(quantity), 0)
            FROM cartdetail
            WHERE cartId = NEW.cartId
        )
    WHERE cartId = NEW.cartId;
END;

