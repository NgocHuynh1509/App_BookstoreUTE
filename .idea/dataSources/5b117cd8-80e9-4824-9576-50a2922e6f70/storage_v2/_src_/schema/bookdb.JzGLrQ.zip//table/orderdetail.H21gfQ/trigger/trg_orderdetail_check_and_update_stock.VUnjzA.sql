create definer = root@localhost trigger trg_orderdetail_check_and_update_stock
    before insert
    on orderdetail
    for each row
BEGIN
    DECLARE current_stock INT;

    SELECT quantity
    INTO current_stock
    FROM books
    WHERE bookId = NEW.bookId
    FOR UPDATE;

    IF current_stock IS NULL THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Book does not exist';
    END IF;

    IF current_stock < NEW.quantity THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'So luong dat vuot qua so luong ton kho';
    END IF;

    UPDATE books
    SET quantity = quantity - NEW.quantity
    WHERE bookId = NEW.bookId;
END;

