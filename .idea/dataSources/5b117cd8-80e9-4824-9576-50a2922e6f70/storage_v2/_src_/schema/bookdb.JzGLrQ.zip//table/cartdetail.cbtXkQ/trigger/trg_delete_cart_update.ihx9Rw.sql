create definer = root@localhost trigger trg_delete_cart_update
    after delete
    on cartdetail
    for each row
BEGIN
    UPDATE cart
    SET
        totalAmount = (
            SELECT COALESCE(SUM(quantity * unitPrice), 0)
            FROM cartdetail
            WHERE cartId = OLD.cartId
        ),
        quantity = (
            SELECT COALESCE(SUM(quantity), 0)
            FROM cartdetail
            WHERE cartId = OLD.cartId
        )
    WHERE cartId = OLD.cartId;
END;

